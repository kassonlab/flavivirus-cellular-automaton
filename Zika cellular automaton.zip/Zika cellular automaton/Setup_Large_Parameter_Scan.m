function Options = Setup_Large_Parameter_Scan(Options,SaveFolderDir)
    
% Define individual parameters that you want to scan
    Params{1,1} = [40000];
    Params{1,2} = [6.8];
    Params{1,3} = [5.7];
    Params{1,4} = [2500];
    Params{1,5} = [25000];

% Enumerate all possible combinations of your defined parameters. Note that
% the number of combinations can get quite large quite quickly...
    Options.ParameterArray = allcomb(Params{1,1:size(Params,2)});

    % Save parameter reference file
    if strcmp(Options.SaveData,'y')
        ParameterReference.ParameterArray = Options.ParameterArray;
        ParameterReference.Params = Params;
        save(strcat(SaveFolderDir,'/',Options.FileLabel,';ParameterReference','.mat'),'ParameterReference')
    end
    
end